from fuzzywuzzy import fuzz,process

print(fuzz.ratio("whenakaaa","thenakaaa"))


